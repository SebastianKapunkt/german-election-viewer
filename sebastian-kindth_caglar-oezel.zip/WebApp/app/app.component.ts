import { Component } from '@angular/core';

import { DashboardComponent } from './dashboard.component'

@Component({
  selector: 'app-root',
  styleUrls: ['css/main.css'],
  template: `
    <dashboard> </dashboard>
  `
})
export class AppComponent {
  title = 'app';
}
