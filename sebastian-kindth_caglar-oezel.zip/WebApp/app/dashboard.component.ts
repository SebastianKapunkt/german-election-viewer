import { Component } from '@angular/core'

@Component({
    selector: 'dashboard',
    template: `
        <state-list>
    `
})

export class DashboardComponent {
    constructor() { }
}